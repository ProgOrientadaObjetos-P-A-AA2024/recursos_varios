/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paqueteuno;

public class Calificacion {

    private double nota;
    private Materia materia;
    private Profesor profesor;

    public Calificacion(double n, Materia nombre) {
        nota = n;
        materia = nombre;
        
    }

    public void establecerNota(double n) {
        nota = n;
    }

    public void establecerMateria(Materia n) {
        materia = n;
    }
    
    public void establecerProfesor(Profesor n) {
        profesor = n;
    }

    public double obtenerNota() {
        return nota;
    }

    public Materia obtenerMateria() {
        return materia;
    }
    
    public Profesor obtenerProfesor() {
        return profesor;
    }

}
