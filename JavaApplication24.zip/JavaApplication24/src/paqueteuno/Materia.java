/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paqueteuno;

public class Materia {
    private String nombre;
    private Carrera carrera;
    
    public void establecerNombre(String n){
        nombre = n;
    }
    
    public void establecerCarrera(Carrera n){
        carrera = n;
    }
    
    public String obtenerNombre(){
        return nombre;
    }
    
    public Carrera obtenerCarrera(){
        return carrera;
    }
}
