/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paqueteuno;

public class Ejecutor {
    public static void main(String[] args) {
        
        Universidad universidad1 = new Universidad("Universidad Técnica Particular de Loja");
        Universidad universidad2 = new Universidad("Universidad de Cuenca");
        Universidad universidad3 = new Universidad("Universidad de Machala");
        
        Carrera carrera1 = new Carrera();
        carrera1.establecerNombre("Ingeniería Quimica");
        carrera1.establecerUniversidad(universidad1);
        
        Carrera carrera2 = new Carrera();
        carrera2.establecerNombre("Ingeniería en Biología");
        carrera2.establecerUniversidad(universidad2);
        
        Carrera carrera3 = new Carrera();
        carrera3.establecerNombre("Ingeniería Forestal");
        carrera3.establecerUniversidad(universidad3);
        
        
        Materia m1 = new Materia();
        m1.establecerNombre("Física");
        m1.establecerCarrera(carrera1);
        
        Materia m2 = new Materia();
        m2.establecerNombre("Computación");
        m2.establecerCarrera(carrera2);
        
        Materia m3 = new Materia();
        m3.establecerNombre("Ecuaciones Diferenciales");
        m3.establecerCarrera(carrera3);
        
        
        Calificacion c1 = new Calificacion(1, m1);
        Calificacion c2 = new Calificacion(9, m2);
        Calificacion c3 = new Calificacion(9.5, m3);
        
        Profesor profesor1 = new Profesor("Isabel Curtis", "tipo 1");
        Profesor profesor2 = new Profesor("Douglas King", "tipo 2");
        Profesor profesor3 = new Profesor("John Luna", "tipo 3");
        
        c1.establecerProfesor(profesor1);
        c2.establecerProfesor(profesor2);
        c3.establecerProfesor(profesor3);
                
        Calificacion [] lista = {c1, c2, c3};
        
        
        LibretaCalificacion libreta1 = new LibretaCalificacion("Adam Robinson",
                lista);
        libreta1.establecerPromedio();
        libreta1.establecerPromedioCualitativo();
        System.out.println(libreta1);
        
    }
}