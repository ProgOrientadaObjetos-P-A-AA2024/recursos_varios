/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paqueteuno;

public class Universidad {
    private String nombre;
    
    public Universidad(String n){
        nombre = n;
    }
    
    public String obtenerNombre(){
        return nombre;
    }
}

