/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paqueteuno;

public class Carrera {
    private String nombre;
    private Universidad universidad;
    
    public void establecerNombre(String s){
        nombre = s;
    }
    
    public void establecerUniversidad(Universidad s){
        universidad = s;
    }
    
    public String obtenerNombre(){
        return nombre;
    }
    
    public Universidad obtenerUniversidad(){
        return universidad;
    }
}
